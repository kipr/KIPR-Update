/*
 * util.hpp
 *
 *  Created on: Nov 13, 2015
 *      Author: Joshua Southerland
 */

#ifndef INCLUDE_WALLABY_UTIL_HPP_
#define INCLUDE_WALLABY_UTIL_HPP_


#include "util.h"


#endif /* INCLUDE_WALLABY_UTIL_HPP_ */
