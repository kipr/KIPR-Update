var class_magneto =
[
    [ "calibrate", "class_magneto.html#aad6df575e83244f06ff0c44a7090dcb5", null ],
    [ "x", "class_magneto.html#a6cd8b048f69a82d53a1fb97caa06fae6", null ],
    [ "y", "class_magneto.html#a88bf053fdfaf8aebf4c520b8142c2ffa", null ],
    [ "z", "class_magneto.html#a0d3eabc6dacbb144ee23a642f8de3073", null ]
];