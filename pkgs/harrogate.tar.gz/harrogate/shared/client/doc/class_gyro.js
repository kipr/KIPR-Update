var class_gyro =
[
    [ "calibrate", "class_gyro.html#a1511a244a256fc6daef2d8e4639afe57", null ],
    [ "x", "class_gyro.html#a452d939a8229fbf3ea699cc06cd3811f", null ],
    [ "y", "class_gyro.html#a82781fcd01e9be0b2bcb6ae29d21140e", null ],
    [ "z", "class_gyro.html#a1f378098d327f14742448e92dc976312", null ]
];