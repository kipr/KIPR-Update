var structpoint3 =
[
    [ "x", "structpoint3.html#a617420d14db862c60053216fa72342de", null ],
    [ "y", "structpoint3.html#a87df35474bb5e0d5ba2d68c522842d0a", null ],
    [ "z", "structpoint3.html#a0380e24b79b7c2576ea6dc79d5e2812b", null ]
];