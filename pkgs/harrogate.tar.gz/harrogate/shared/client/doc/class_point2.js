var class_point2 =
[
    [ "Point2", "class_point2.html#a39957faf4f3de74f3f9f06097a15cd81", null ],
    [ "column", "class_point2.html#a847cdf60948df4e4a875fc2fc40a067f", null ],
    [ "row", "class_point2.html#a22eab082a8720e35f491d48e024c40e9", null ],
    [ "setColumn", "class_point2.html#a019317ddb6eb35a2e6193ddef8f8fb16", null ],
    [ "setRow", "class_point2.html#a2ec7f059e74e42aaf7d0fb8ca14b8d96", null ],
    [ "setX", "class_point2.html#ad98911764a2432860b3987775548f408", null ],
    [ "setY", "class_point2.html#a3431f5a8ae076ab88286564c3397bde0", null ],
    [ "toCPoint2", "class_point2.html#a9a51f27acb903bdb405c06e0c9a383eb", null ],
    [ "x", "class_point2.html#ac0bb9084384545c9abc9e6ae99e7f1c4", null ],
    [ "y", "class_point2.html#a4d4859e867145650f750599520adc1e8", null ]
];