var class_address =
[
    [ "Address", "class_address.html#a48f07460b0e2f9c3363b15a4575f1246", null ],
    [ "Address", "class_address.html#a7112bb43b003883514eebd942f3c88c5", null ],
    [ "Address", "class_address.html#a63f910c09d93bdd16d3744e47d13dc0e", null ],
    [ "addr", "class_address.html#a1a4b93cc514debcc9b16a394e999c0d1", null ],
    [ "addrLength", "class_address.html#adb588eb62d540ae5fc201be9327f64b0", null ],
    [ "ip", "class_address.html#ab15bcf13e259d3db77299966237db755", null ],
    [ "isValid", "class_address.html#a5841663a610521d8051e139408b845cb", null ],
    [ "port", "class_address.html#a5d0aa91c99440e84cd8b799e2fe9e01b", null ],
    [ "setHost", "class_address.html#a46d0a5cd67550608d49e422bad632d09", null ],
    [ "setPort", "class_address.html#a7c3715175945e8e1f7ff16e92ed0f85c", null ]
];