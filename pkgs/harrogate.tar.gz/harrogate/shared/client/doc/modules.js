var modules =
[
    [ "Accelerometer", "group__accel.html", "group__accel" ],
    [ "Analogs", "group__analog.html", "group__analog" ],
    [ "Battery", "group__battery.html", "group__battery" ],
    [ "Buttons", "group__button.html", "group__button" ],
    [ "Camera", "group__camera.html", "group__camera" ],
    [ "Compass", "group__compass.html", "group__compass" ],
    [ "Console", "group__console.html", "group__console" ],
    [ "iRobot (R) Create (TM)", "group__create.html", "group__create" ],
    [ "Digitals", "group__digital.html", "group__digital" ],
    [ "General", "group__general.html", "group__general" ],
    [ "Graphics", "group__graphics.html", "group__graphics" ],
    [ "Gyrometer", "group__gyro.html", "group__gyro" ],
    [ "Magnetometer", "group__magneto.html", "group__magneto" ],
    [ "Motors", "group__motor.html", "group__motor" ],
    [ "Servos", "group__servo.html", "group__servo" ],
    [ "Threading", "group__thread.html", "group__thread" ]
];