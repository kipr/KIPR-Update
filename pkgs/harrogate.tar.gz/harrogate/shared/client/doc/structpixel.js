var structpixel =
[
    [ "b", "structpixel.html#a25bc8317f2c216b3702d5fac2e6fc306", null ],
    [ "g", "structpixel.html#a6f4b39b225373a1404c8424c176f4006", null ],
    [ "r", "structpixel.html#a2cc21269c11bd75b6da2249d177257f0", null ]
];