var socket_8hpp =
[
    [ "Address", "class_address.html", "class_address" ],
    [ "Socket", "class_socket.html", "class_socket" ],
    [ "socket_fd_t", "socket_8hpp.html#ac5edad8c23925f7425866e7253f7f02a", null ]
];