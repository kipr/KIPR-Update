var ir_8h =
[
    [ "ir_read", "ir_8h.html#afe734b1ef0d2a3a4fb24bd53526ea98d", null ],
    [ "ir_write", "ir_8h.html#a51b3067436e5d93e151dc1694ddfc8ed", null ]
];