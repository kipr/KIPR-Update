var struct_rgb =
[
    [ "b", "struct_rgb.html#acab4ec8e0d55174258da75ee80f69bef", null ],
    [ "g", "struct_rgb.html#a27a8958ecb91f5f98ee520129a396ce3", null ],
    [ "r", "struct_rgb.html#a3da778daa4ccbc628c478b21d6093df5", null ]
];