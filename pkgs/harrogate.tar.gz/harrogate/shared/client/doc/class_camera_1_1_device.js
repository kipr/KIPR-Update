var class_camera_1_1_device =
[
    [ "Device", "class_camera_1_1_device.html#ad3019d05af5bdc301477e18487de6b6a", null ],
    [ "~Device", "class_camera_1_1_device.html#aa84763523fe4b069f8e4d909386bd0c5", null ],
    [ "bgr", "class_camera_1_1_device.html#addbc9ab9bdd4c3df540e38b21a22ed96", null ],
    [ "channels", "class_camera_1_1_device.html#a076929b719960ea6bf1e5d9001da23a8", null ],
    [ "close", "class_camera_1_1_device.html#a59747ebb798f720f1f175356e14646b8", null ],
    [ "config", "class_camera_1_1_device.html#af034054abfa6ffa68262d5518072c098", null ],
    [ "height", "class_camera_1_1_device.html#a5de060c1f0253fe70571966661922666", null ],
    [ "isOpen", "class_camera_1_1_device.html#a2943ec66997b42446c91db8044063f5f", null ],
    [ "open", "class_camera_1_1_device.html#a6945ee818b88ba0a50202c2a48e66c17", null ],
    [ "rawImage", "class_camera_1_1_device.html#ac80c88707f80112834b1cf58a27ebf11", null ],
    [ "resolutionToHeight", "class_camera_1_1_device.html#a7d80abf74f1ee2a6ab5590941e27bc2a", null ],
    [ "resolutionToWidth", "class_camera_1_1_device.html#af7ec7e7d39417667657a2af257195f1f", null ],
    [ "setConfig", "class_camera_1_1_device.html#a6a54b6052fdcc5e3764d4dda683ff3d7", null ],
    [ "setHeight", "class_camera_1_1_device.html#afe16c7b192544e51014988290eedb66a", null ],
    [ "setWidth", "class_camera_1_1_device.html#a3713ea3cd393ccc939da314159f65078", null ],
    [ "update", "class_camera_1_1_device.html#a7aed06fe32d501f6bc16b3eade0ae9f9", null ],
    [ "width", "class_camera_1_1_device.html#a542478b7d702d2ec0f52c378aef700a1", null ]
];