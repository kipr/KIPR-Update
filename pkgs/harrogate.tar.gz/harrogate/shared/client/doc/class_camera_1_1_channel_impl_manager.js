var class_camera_1_1_channel_impl_manager =
[
    [ "channelImpl", "class_camera_1_1_channel_impl_manager.html#a1ea5280ab3b4efa6e20a309730e4e7cb", null ],
    [ "setImage", "class_camera_1_1_channel_impl_manager.html#a62b2bff38f81507a9e638275469b4044", null ]
];