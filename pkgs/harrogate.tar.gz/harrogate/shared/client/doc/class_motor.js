var class_motor =
[
    [ "Motor", "class_motor.html#ae67e1f5998d424f82101a7105fcc4ade", null ],
    [ "backward", "class_motor.html#a53f7df4ef6392b0a16debbaba5653812", null ],
    [ "blockMotorDone", "class_motor.html#a13d07d29eb2769f9c9d3c1a8521c6ab1", null ],
    [ "clearPositionCounter", "class_motor.html#a2d7709129af429dc3dd58100985fe328", null ],
    [ "forward", "class_motor.html#ae804085b9a09f64031558711bfd700ac", null ],
    [ "freeze", "class_motor.html#a28a3af6d7d140e135469989d23e91ac9", null ],
    [ "isMotorDone", "class_motor.html#a37665f3c455fc3a308f705d4a33e6455", null ],
    [ "motor", "class_motor.html#a6483b672f45e1978811c1e8b277952d1", null ],
    [ "motorPower", "class_motor.html#a067344cc9e9b64ffda61e0447274fa29", null ],
    [ "moveAtVelocity", "class_motor.html#a348b2463eca9f203a732caded796c38a", null ],
    [ "moveRelativePosition", "class_motor.html#ad05127d4ef3d40045d902563a805a960", null ],
    [ "moveToPosition", "class_motor.html#ac932694a5660ee8a0aa7526e7d6bca5d", null ],
    [ "off", "class_motor.html#a87114720f6d0e03d7195115ed77dc93b", null ],
    [ "pidGains", "class_motor.html#a4b9aa114213018be186f6adad185ef3e", null ],
    [ "port", "class_motor.html#af772f9e1265a13d983294886259e3603", null ],
    [ "setPidGains", "class_motor.html#a8b64db31827e23ddd34bdd1d9dc561af", null ]
];