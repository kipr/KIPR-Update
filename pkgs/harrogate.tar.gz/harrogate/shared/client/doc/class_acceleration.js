var class_acceleration =
[
    [ "calibrate", "class_acceleration.html#a6e4dbb9d4a6047469441bd4c46e11a73", null ],
    [ "x", "class_acceleration.html#a47962645fcb58ce10c7ae748aa53120e", null ],
    [ "y", "class_acceleration.html#a355ced109c51dd583df43c143ba8a273", null ],
    [ "z", "class_acceleration.html#a73a471130d01b00d01499c43da23f355", null ]
];