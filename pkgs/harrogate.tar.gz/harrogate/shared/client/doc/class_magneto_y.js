var class_magneto_y =
[
    [ "value", "class_magneto_y.html#aa66cb9ff56216c8f6d08df8084c50bed", null ]
];