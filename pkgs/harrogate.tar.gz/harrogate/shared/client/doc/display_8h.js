var display_8h =
[
    [ "display_clear", "display_8h.html#a6c8381cd97a94a67a35d86b0c5308b3a", null ],
    [ "display_printf", "display_8h.html#abbf993d2dc1de781d106a1ca2c8c484d", null ]
];