var searchData=
[
  ['white_5f2016',['WHITE_2016',['../camera_8h.html#a051e4d035e053a4636efc58c1bde9b3eade38c5b2c8031780d3866d4d8caf33eb',1,'camera.h']]]
];
