var searchData=
[
  ['b',['b',['../structpixel.html#a25bc8317f2c216b3702d5fac2e6fc306',1,'pixel::b()'],['../struct_rgb.html#acab4ec8e0d55174258da75ee80f69bef',1,'Rgb::b()'],['../namespace_button.html#aef3b1b348ac209097267cb616a457117',1,'Button::B()']]],
  ['batterycapacity',['batteryCapacity',['../struct_create_packets_1_1__3.html#a85f75185084576a55e46fe5eb0349c5b',1,'CreatePackets::_3']]],
  ['batterycharge',['batteryCharge',['../struct_create_packets_1_1__3.html#a99765c58499dab09b523b92a7031029c',1,'CreatePackets::_3']]],
  ['batterytemperature',['batteryTemperature',['../struct_create_packets_1_1__3.html#a98bfbfddc61369035fdee724ae26e4c2',1,'CreatePackets::_3']]],
  ['bumpsandwheeldrops',['bumpsAndWheelDrops',['../struct_create_packets_1_1__1.html#aa9a7ef4753c4fbe5a73ee4f9022badf6',1,'CreatePackets::_1']]],
  ['buttons',['buttons',['../struct_create_packets_1_1__2.html#a6b7d2d6c0a3a063f873420c010063b33',1,'CreatePackets::_2']]]
];
