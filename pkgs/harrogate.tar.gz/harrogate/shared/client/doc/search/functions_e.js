var searchData=
[
  ['object',['Object',['../class_camera_1_1_object.html#ae62cb68e3cc16bcf08812f0a64ba75dc',1,'Camera::Object::Object(const Point2&lt; unsigned &gt; &amp;centroid, const Rect&lt; unsigned &gt; &amp;boundingBox, const double confidence, const char *data=0, const size_t &amp;dataLength=0)'],['../class_camera_1_1_object.html#ad721a78cffe2c028cf26940c1ae8b3c9',1,'Camera::Object::Object(const Object &amp;rhs)']]],
  ['objects',['objects',['../class_camera_1_1_channel_impl.html#a3686779bf5471c4263165a28df7150dd',1,'Camera::ChannelImpl::objects()'],['../class_camera_1_1_channel.html#a04cd7b9110dd4d1a614f9a23bc0fe3db',1,'Camera::Channel::objects()']]],
  ['off',['off',['../class_motor.html#a87114720f6d0e03d7195115ed77dc93b',1,'Motor::off()'],['../group__motor.html#gab32a8ae225a031b09e355e0813bec06f',1,'off():&#160;motors.h']]],
  ['open',['open',['../class_camera_1_1_device.html#a6945ee818b88ba0a50202c2a48e66c17',1,'Camera::Device::open()'],['../class_socket.html#ac29147e85ea697c250cdb9f6bfdd72cb',1,'Socket::open()']]],
  ['operator_3d',['operator=',['../class_create_script.html#a6ccdd4d083ff90c0f69fc02dd38f2f7b',1,'CreateScript']]],
  ['or',['Or',['../class_sensor_logic_1_1_or.html#a90a91f5f81b4d914a7ab0f06295030ad',1,'SensorLogic::Or']]],
  ['owns',['owns',['../class_sensor_logic_1_1_base.html#aaf1a6428bf9352cbfe5a2a53c330f4d6',1,'SensorLogic::Base::owns()'],['../class_sensor_logic_1_1_not.html#a51b0628680fce6076055b65c33196dcb',1,'SensorLogic::Not::owns()']]]
];
