var searchData=
[
  ['socket_5ffd_5ft',['socket_fd_t',['../socket_8hpp.html#ac5edad8c23925f7425866e7253f7f02a',1,'socket.hpp']]]
];
