var searchData=
[
  ['segl',['SEGL',['../graphics__characters_8h.html#ad3b15ff105e16268758a59e0b228827b',1,'graphics_characters.h']]],
  ['segsp',['SEGSP',['../graphics__characters_8h.html#a30b74409594687262e85c1273457333d',1,'graphics_characters.h']]]
];
