var searchData=
[
  ['ir',['ir',['../struct_create_packets_1_1__2.html#ac834057741105e898b3d4613b96c6eb1',1,'CreatePackets::_2']]]
];
