var searchData=
[
  ['high_5fres',['HIGH_RES',['../camera_8h.html#a3c1fc1369ee351f25804c8cde5e85ac3ab9d3cdf4dc2819081ce68db47475e9ad',1,'camera.h']]]
];
