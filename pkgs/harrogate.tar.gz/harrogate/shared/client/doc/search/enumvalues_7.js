var searchData=
[
  ['med_5fres',['MED_RES',['../camera_8h.html#a3c1fc1369ee351f25804c8cde5e85ac3a31c6c4c7336d70b5b00cf635080641e7',1,'camera.h']]]
];
