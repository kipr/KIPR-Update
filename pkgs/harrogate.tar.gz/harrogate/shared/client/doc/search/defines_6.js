var searchData=
[
  ['nobold',['NOBOLD',['../graphics__characters_8h.html#a6bf68eac37fdc98b9ee189b7fee29f69',1,'graphics_characters.h']]],
  ['numseg',['NUMSEG',['../graphics__characters_8h.html#a0217cd28fb19053772dfe9df4c8276d4',1,'graphics_characters.h']]]
];
