var searchData=
[
  ['native_5fres',['NATIVE_RES',['../camera_8h.html#a3c1fc1369ee351f25804c8cde5e85ac3a2bd5d757a7a7770b41543ff935608470',1,'camera.h']]]
];
