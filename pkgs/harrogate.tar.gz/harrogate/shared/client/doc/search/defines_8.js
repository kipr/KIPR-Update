var searchData=
[
  ['pi',['PI',['../create_8hpp.html#a598a3330b3c21701223ee0ca14316eca',1,'create.hpp']]],
  ['possibly_5funused',['POSSIBLY_UNUSED',['../vtable_8h.html#a24445876f3ab7d76a0e046943fcadace',1,'vtable.h']]],
  ['prettyfunc',['PRETTYFUNC',['../compat_8hpp.html#a38c97dd9052c61441dc20539e20b7c53',1,'compat.hpp']]]
];
