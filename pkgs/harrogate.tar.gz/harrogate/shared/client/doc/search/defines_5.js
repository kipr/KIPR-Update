var searchData=
[
  ['initializer',['INITIALIZER',['../compat_8hpp.html#a8e1958511f31a98a5bb11bc7e34d7696',1,'compat.hpp']]]
];
