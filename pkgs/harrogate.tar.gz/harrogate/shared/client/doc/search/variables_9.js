var searchData=
[
  ['mainbrushmotorcurrent',['mainBrushMotorCurrent',['../struct_create_packets_1_1__101.html#a0cbb83f589f640d0093df33b7a27a051',1,'CreatePackets::_101']]],
  ['mode',['mode',['../struct_create_packets_1_1__5.html#a8e0aa367e92d1f71fb5529aebc0524fe',1,'CreatePackets::_5']]]
];
