var searchData=
[
  ['b',['B',['../namespace_button_1_1_type.html#a53d13b3f26501127fef45668d0a2bc69a53241bd774d7e061e162bcc6730a6882',1,'Button::Type']]],
  ['baud115200',['Baud115200',['../class_create.html#aa23ac3aaa860b6d4d7d0d77f85cb6045a2c5e9ffec08bd5a34ce6ab220bcda6b9',1,'Create::Baud115200()'],['../create_8h.html#a7654bd82719bfde1c792d7828664dde2af95051e227854027d600a358d5dbfb44',1,'Baud115200():&#160;create.h']]],
  ['baud57600',['Baud57600',['../class_create.html#aa23ac3aaa860b6d4d7d0d77f85cb6045af655be100ff53b246fb36865cd53cc0e',1,'Create::Baud57600()'],['../create_8h.html#a7654bd82719bfde1c792d7828664dde2afa5801ed32e6bf3556cf937a2edc9e6d',1,'Baud57600():&#160;create.h']]],
  ['bgr',['BGR',['../graphics_8h.html#afb0564821f132bfe74508af8349a0faaa4a19a93c929964c201e01c8352dc8b9c',1,'graphics.h']]],
  ['black_5f2017',['BLACK_2017',['../camera_8h.html#a051e4d035e053a4636efc58c1bde9b3ea38f2beaf8e06a06776412da04c79bfb9',1,'camera.h']]]
];
