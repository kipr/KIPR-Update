var searchData=
[
  ['g',['g',['../structpixel.html#a6f4b39b225373a1404c8424c176f4006',1,'pixel::g()'],['../struct_rgb.html#a27a8958ecb91f5f98ee520129a396ce3',1,'Rgb::g()']]]
];
