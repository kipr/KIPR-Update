var struct_create_packets_1_1__1 =
[
    [ "bumpsAndWheelDrops", "struct_create_packets_1_1__1.html#aa9a7ef4753c4fbe5a73ee4f9022badf6", null ],
    [ "cargoBayDigitalInputs", "struct_create_packets_1_1__1.html#ac4390671e6a1d470a003810079f5515d", null ],
    [ "cliffFrontLeft", "struct_create_packets_1_1__1.html#a3b75b8bc5ba7ef9639ad8850fc60b7a2", null ],
    [ "cliffFrontRight", "struct_create_packets_1_1__1.html#aeaae39fc49fd86b6d8f4f4b355f398f8", null ],
    [ "cliffLeft", "struct_create_packets_1_1__1.html#acd14195f818fe7233ce54ebb3a456175", null ],
    [ "cliffRight", "struct_create_packets_1_1__1.html#a3b4744173f01875647e1e4188454de5e", null ],
    [ "lowSideDriverAndWheelOvercurrents", "struct_create_packets_1_1__1.html#aed626674619a61cabf18e1983e662181", null ],
    [ "virtualWall", "struct_create_packets_1_1__1.html#ae5bc1f0f99fc1ca2cb164fac7c8dfe0b", null ],
    [ "wall", "struct_create_packets_1_1__1.html#a4e6875c26a8766b3af098a12ad2bd5ad", null ]
];