var wait__for_8h =
[
    [ "wait_for_a_button", "wait__for_8h.html#abf3c8487a7b61583668b56f156e6d229", null ],
    [ "wait_for_a_button_clicked", "wait__for_8h.html#ad88657b5ba6ca4dc1be171d197d90844", null ],
    [ "wait_for_any_button", "wait__for_8h.html#a52e916a20ed81c1ec6813e47eb5611b3", null ],
    [ "wait_for_b_button", "wait__for_8h.html#a31818a1afacff0e2efcc219362dc8c57", null ],
    [ "wait_for_b_button_clicked", "wait__for_8h.html#abacda87dab738e98c28c7abec3d8f75d", null ],
    [ "wait_for_c_button", "wait__for_8h.html#a0945643072a172035cb7aab9a889f4dc", null ],
    [ "wait_for_c_button_clicked", "wait__for_8h.html#ac770f0dd8aef734041f4ce60f49c6970", null ],
    [ "wait_for_milliseconds", "wait__for_8h.html#aa46c26b7af76957ed9883455fae66c46", null ],
    [ "wait_for_side_button", "wait__for_8h.html#ad445d9f9652220a36980819015d15cc7", null ],
    [ "wait_for_side_button_clicked", "wait__for_8h.html#aa19067ebb6c3cb02c481d8876488b276", null ],
    [ "wait_for_touch", "wait__for_8h.html#abdea0006c681ab71eb931d9b472d7212", null ],
    [ "wait_for_x_button", "wait__for_8h.html#a91ac6df8a324de53cd3ee6601179d30e", null ],
    [ "wait_for_x_button_clicked", "wait__for_8h.html#a49bd0c5eecb2b5d961fe368d4ad201df", null ],
    [ "wait_for_y_button", "wait__for_8h.html#a9a6b9033c79566330dbc130f6b74e73a", null ],
    [ "wait_for_y_button_clicked", "wait__for_8h.html#a8854833272d9ece73e7df068e414c55c", null ],
    [ "wait_for_z_button", "wait__for_8h.html#a074301305cf8e5f7e825e7d53fedb522", null ],
    [ "wait_for_z_button_clicked", "wait__for_8h.html#ac434d52511ced8c9542b16f1a359550b", null ]
];