var group__digital =
[
    [ "digital", "group__digital.html#ga3eb7db79d996b92f7063b65dc34b3484", null ],
    [ "get_digital_output", "group__digital.html#ga865e9d1807739ddc9585c5665de1281c", null ],
    [ "get_digital_pullup", "group__digital.html#ga2d37bb1981515925418bd5a624eb1aa6", null ],
    [ "get_digital_value", "group__digital.html#ga4b672bd3758b1ff255b0bc51d6c9fd76", null ],
    [ "set_digital_output", "group__digital.html#gac6aacd543334547b664ff839888bfbe2", null ],
    [ "set_digital_pullup", "group__digital.html#ga6f4483ed1b9532f7637d79255107d2e9", null ],
    [ "set_digital_value", "group__digital.html#ga1e12c564407ca4edc4c833ddb9f0344f", null ]
];