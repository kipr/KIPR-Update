var class_sensor_logic_1_1_or =
[
    [ "Or", "class_sensor_logic_1_1_or.html#a90a91f5f81b4d914a7ab0f06295030ad", null ],
    [ "value", "class_sensor_logic_1_1_or.html#a17ca95e8e67e64cb2d59fdd1c9c98654", null ]
];