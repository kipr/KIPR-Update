var struct_create_packets_1_1__3 =
[
    [ "batteryCapacity", "struct_create_packets_1_1__3.html#a85f75185084576a55e46fe5eb0349c5b", null ],
    [ "batteryCharge", "struct_create_packets_1_1__3.html#a99765c58499dab09b523b92a7031029c", null ],
    [ "batteryTemperature", "struct_create_packets_1_1__3.html#a98bfbfddc61369035fdee724ae26e4c2", null ],
    [ "chargingState", "struct_create_packets_1_1__3.html#a91cdd41bfb848100513c43a6dbb573db", null ],
    [ "current", "struct_create_packets_1_1__3.html#ac85cd935ac8a22003afc2f46c58031fc", null ],
    [ "voltage", "struct_create_packets_1_1__3.html#adf59c3b3df4a555dcbf22e5704194a72", null ]
];