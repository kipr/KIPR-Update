var class_battery =
[
    [ "isCharging", "class_battery.html#a9cc367a63d6c3dd71e7967792bc18968", null ],
    [ "powerLevel", "class_battery.html#afead1880eafc4022fc57528a056d258b", null ],
    [ "rawPowerADC", "class_battery.html#a61ec9b29dc6d7ae6e1166f77ccccb200", null ]
];