var class_ir =
[
    [ "read", "class_ir.html#a6b1cb5bcee8cd99c5fa73034c76f8c18", null ],
    [ "write", "class_ir.html#a1fce580db04daaf6e404781a5e935afc", null ]
];