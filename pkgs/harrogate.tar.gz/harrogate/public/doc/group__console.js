var group__console =
[
    [ "Console", "class_console.html", [
      [ "clear", "class_console.html#a37a8561cc9b3ae7367290fe1667ba0db", null ]
    ] ],
    [ "console_clear", "group__console.html#ga00450156795a2e67a33731ead413a981", null ]
];