var structrectangle =
[
    [ "height", "structrectangle.html#af460193d9a375b8e2813bf1fe6216cce", null ],
    [ "ulx", "structrectangle.html#a4feece2ec58d909444613177ec67e2bc", null ],
    [ "uly", "structrectangle.html#ac537f5c6afbda6ef42cc428540058ecb", null ],
    [ "width", "structrectangle.html#a57a9b24a714057d8d2ca9a06333560d3", null ]
];