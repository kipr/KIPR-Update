var magneto_8h =
[
    [ "magneto_calibrate", "group__magneto.html#gafbf1a4a817f6d906b3f56febed343122", null ],
    [ "magneto_x", "group__magneto.html#gabec77e162ab72f3c63f91a006f51b2c4", null ],
    [ "magneto_y", "group__magneto.html#gab536ca9dc29118ba2f1231c011531e7b", null ],
    [ "magneto_z", "group__magneto.html#ga78e58e4d74bfe1767d090644010a574d", null ]
];