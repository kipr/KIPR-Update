var general_8h =
[
    [ "freeze_halt", "general_8h.html#ae386a2b5c14b4291274d1224dbe43bb6", null ],
    [ "halt", "general_8h.html#a872b045588895c9c480392cf746ab9ec", null ],
    [ "publish", "group__general.html#ga2955f8e823ea99f92d32a86f21a5dab2", null ],
    [ "set_auto_publish", "group__general.html#ga038517d3df8f236dde8eefbbcadee37e", null ]
];