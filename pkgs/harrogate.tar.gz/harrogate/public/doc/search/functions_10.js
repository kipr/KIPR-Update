var searchData=
[
  ['rawimage',['rawImage',['../class_camera_1_1_device.html#ac80c88707f80112834b1cf58a27ebf11',1,'Camera::Device']]],
  ['rawpoweradc',['rawPowerADC',['../class_battery.html#a61ec9b29dc6d7ae6e1166f77ccccb200',1,'Battery']]],
  ['read',['read',['../class_create.html#a177838426044d3c0100318ada011522f',1,'Create::read()'],['../class_create.html#ab89b4e07f162f3103a33800269c74cc8',1,'Create::read(unsigned char *data, const size_t &amp;len)'],['../class_ir.html#a6b1cb5bcee8cd99c5fa73034c76f8c18',1,'Ir::read()']]],
  ['rect',['Rect',['../class_rect.html#af3ea475d7450e39eaeb2237de3b1c0b2',1,'Rect']]],
  ['recv',['recv',['../class_socket.html#a0a0ee366bc625b8f0d435cf68d083157',1,'Socket']]],
  ['recvfrom',['recvfrom',['../class_socket.html#a1f9437723ddf95179268958407383f1c',1,'Socket']]],
  ['refreshrate',['refreshRate',['../class_create.html#a6aba67344d17731690a7b20205590246',1,'Create']]],
  ['register_5fvalue',['register_value',['../debug_8h.html#a741ac2c9bcc99558c55e0ad27577c50b',1,'debug.h']]],
  ['remove',['remove',['../class_create_script.html#a053dc84182f532b3516ec01a3ee5d18b',1,'CreateScript']]],
  ['resettext',['resetText',['../class_abstract_text_button.html#aa76b8ad84d4a4f3d9ca0daa11975b875',1,'AbstractTextButton::resetText()'],['../class_id_button.html#aafb9032f4f241438ac3755674dc3f0d1',1,'IdButton::resetText()']]],
  ['resolutiontoheight',['resolutionToHeight',['../class_camera_1_1_device.html#a7d80abf74f1ee2a6ab5590941e27bc2a',1,'Camera::Device']]],
  ['resolutiontowidth',['resolutionToWidth',['../class_camera_1_1_device.html#af7ec7e7d39417667657a2af257195f1f',1,'Camera::Device']]],
  ['right_5fbutton',['right_button',['../group__button.html#ga22b4859d4454499466dea2293d109d6d',1,'button.h']]],
  ['row',['row',['../class_point2.html#a22eab082a8720e35f491d48e024c40e9',1,'Point2']]],
  ['run',['run',['../class_thread.html#aae90dfabab3e1776cf01a26e7ee3a620',1,'Thread']]]
];
