var searchData=
[
  ['resolution',['Resolution',['../camera_8h.html#a3c1fc1369ee351f25804c8cde5e85ac3',1,'camera.h']]]
];
