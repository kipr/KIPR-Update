var searchData=
[
  ['thread_5ffunction',['thread_function',['../thread_8h.html#a8e3564199059191e2e89c86bd95dfaed',1,'thread.h']]],
  ['ticks_5ft',['ticks_t',['../class_servo.html#a5c29b5dbeeb014967bc2fbe9d3a09b11',1,'Servo']]]
];
