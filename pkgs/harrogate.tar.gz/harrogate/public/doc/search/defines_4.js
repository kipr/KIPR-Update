var searchData=
[
  ['gxwindow',['GXWINDOW',['../graphics__characters_8h.html#aeecdf9fb2fee51ed741519397463031b',1,'graphics_characters.h']]],
  ['gywindow',['GYWINDOW',['../graphics__characters_8h.html#a3135004fb6c11ea109090c92a2970250',1,'graphics_characters.h']]]
];
