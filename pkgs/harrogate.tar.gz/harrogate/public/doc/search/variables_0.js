var searchData=
[
  ['_5f_5fbold',['__bold',['../graphics__characters_8h.html#a3c9517bdfadb5efb1bbd0749da651af4',1,'graphics_characters.h']]]
];
